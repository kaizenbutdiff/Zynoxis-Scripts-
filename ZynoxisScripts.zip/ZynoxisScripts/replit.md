# Zynoxis Scripts - Roblox Script Hub

## Overview

Zynoxis Scripts is a modern web-based Roblox script hub that allows users to browse, search, and access scripts for various Roblox games. The application features a sleek, space-themed UI with animated elements and provides a centralized platform for script distribution. **Status: Complete and fully functional** (July 23, 2025)

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

**July 23, 2025 - Project Completion:**
- Successfully delivered complete Zynoxis Scripts website
- User extremely satisfied with the final result ("IT'S SO GOOD")
- All features working perfectly: animations, navigation, clipboard functionality, analytics
- Dark theme and space aesthetic achieved desired visual impact

**July 23, 2025 - Private Hub Configuration:**
- Configured as private script hub controlled by user
- Empty scripts.json file ready for user's custom script additions
- Updated descriptions to reflect personal/private nature
- Added professional disclaimer for responsible usage
- Created custom favicon for brand consistency
- **Status: Ready for private use - user controls all script content**

## System Architecture

### Frontend Architecture
- **Pure HTML/CSS/JavaScript**: Static frontend without frameworks
- **Responsive Design**: Mobile-first approach with CSS Grid and Flexbox
- **Animation System**: CSS animations and JavaScript-driven scroll reveals
- **Modular Structure**: Separate pages for home and scripts listing

### Client-Side Rendering
- Scripts are loaded dynamically from a JSON file
- Real-time search and filtering functionality
- Analytics tracking for script usage

## Key Components

### 1. Home Page (index.html)
- **Hero Section**: Landing page with animated Saturn logo and call-to-action
- **Particle System**: Animated background particles for visual appeal
- **Navigation**: Simple button to browse scripts

### 2. Scripts Page (scripts.html)
- **Navigation Bar**: Back to home functionality with branded logo
- **Search System**: Real-time filtering of scripts by game or script name
- **Scripts Grid**: Card-based layout displaying script information
- **Analytics Panel**: Usage statistics and metrics

### 3. Script Management (js/scriptLoader.js)
- **ScriptManager Class**: Central controller for script operations
- **Async Loading**: Fetches scripts from JSON data source
- **Search Functionality**: Client-side filtering and rendering
- **Error Handling**: Graceful fallbacks for failed requests
- **Analytics Tracking**: User interaction monitoring

### 4. Data Layer (scripts.json)
- **Static JSON**: Contains script metadata including:
  - Game name
  - Script name
  - External script URL (Pastebin links)

## Data Flow

1. **Initial Load**: Home page renders with animations
2. **Navigation**: User clicks "Browse Scripts" to navigate to scripts page
3. **Script Loading**: ScriptManager fetches scripts.json and renders cards
4. **Search Interaction**: Real-time filtering updates displayed scripts
5. **Script Access**: Users copy script URLs for external use
6. **Analytics**: Usage data is tracked and displayed

## External Dependencies

### Third-Party Services
- **Pastebin**: Script hosting and distribution
- **Google Fonts**: Orbitron and Exo 2 font families
- **Font Awesome**: Icon library for UI elements

### CDN Resources
- Font Awesome CSS (version 6.0.0)
- Google Fonts API

## Deployment Strategy

### Static Hosting Requirements
- **File Structure**: All assets served statically
- **No Backend**: Client-side only application
- **Cross-Origin**: May require CORS configuration for JSON loading
- **CDN Compatibility**: External resources loaded from CDNs

### Performance Considerations
- **Lazy Loading**: Scripts loaded on demand
- **Animation Optimization**: CSS transforms and transitions
- **Responsive Images**: SVG graphics for scalability
- **Minimal Dependencies**: Lightweight vanilla JavaScript approach

### Security Considerations
- **XSS Prevention**: HTML escaping for user-generated content
- **External Links**: Scripts hosted on external platforms
- **No Authentication**: Public access to all content