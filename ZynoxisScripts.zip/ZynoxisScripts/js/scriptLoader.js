class ScriptManager {
    constructor() {
        this.scripts = [];
        this.init();
    }

    async init() {
        this.showLoading(true);
        await this.loadScripts();
        this.renderScripts();
        this.setupEventListeners();
        this.showLoading(false);
        this.setupScrollAnimations();
    }

    async loadScripts() {
        try {
            const response = await fetch('scripts.json');
            if (!response.ok) {
                throw new Error('Failed to fetch scripts');
            }
            this.scripts = await response.json();
        } catch (error) {
            console.error('Error loading scripts:', error);
            this.showError('Failed to load scripts. Please try again later.');
        }
    }

    renderScripts(filteredScripts = null) {
        const scriptsGrid = document.getElementById('scriptsGrid');
        const scriptsToRender = filteredScripts || this.scripts;
        
        if (scriptsToRender.length === 0) {
            scriptsGrid.innerHTML = `
                <div class="no-scripts">
                    <i class="fas fa-search" style="font-size: 3rem; color: var(--text-secondary); margin-bottom: 1rem;"></i>
                    <h3>No scripts found</h3>
                    <p>Try adjusting your search terms</p>
                </div>
            `;
            return;
        }

        scriptsGrid.innerHTML = scriptsToRender.map((script, index) => `
            <div class="script-card scroll-reveal" style="animation-delay: ${index * 0.1}s">
                <div class="script-game">${this.escapeHtml(script.game)}</div>
                <div class="script-name">${this.escapeHtml(script.name)}</div>
                <div class="script-actions">
                    <button class="copy-btn" data-script="${this.escapeHtml(script.script)}" data-name="${this.escapeHtml(script.name)}">
                        <i class="fas fa-copy"></i>
                        Copy Script
                    </button>
                </div>
            </div>
        `).join('');

        // Re-setup scroll animations for new elements
        this.setupScrollAnimations();
    }

    setupEventListeners() {
        // Search functionality
        const searchInput = document.getElementById('searchInput');
        searchInput.addEventListener('input', (e) => {
            this.handleSearch(e.target.value);
        });

        // Copy button functionality
        document.getElementById('scriptsGrid').addEventListener('click', (e) => {
            if (e.target.closest('.copy-btn')) {
                const button = e.target.closest('.copy-btn');
                const scriptUrl = button.dataset.script;
                const scriptName = button.dataset.name;
                this.copyToClipboard(scriptUrl, scriptName);
            }
        });

        // Page load animations
        setTimeout(() => {
            document.querySelectorAll('.fade-in').forEach((element, index) => {
                setTimeout(() => {
                    element.classList.add('active');
                }, index * 200);
            });
        }, 100);
    }

    handleSearch(query) {
        if (!query.trim()) {
            this.renderScripts();
            return;
        }

        const filteredScripts = this.scripts.filter(script => 
            script.name.toLowerCase().includes(query.toLowerCase()) ||
            script.game.toLowerCase().includes(query.toLowerCase())
        );

        this.renderScripts(filteredScripts);
    }

    async copyToClipboard(scriptUrl, scriptName) {
        try {
            await navigator.clipboard.writeText(scriptUrl);
            this.showToast(`${scriptName} copied to clipboard!`);
        } catch (error) {
            console.error('Failed to copy to clipboard:', error);
            // Fallback for older browsers
            this.fallbackCopyToClipboard(scriptUrl);
            this.showToast(`${scriptName} copied to clipboard!`);
        }
    }

    fallbackCopyToClipboard(text) {
        const textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        textArea.style.top = '-999999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        
        try {
            document.execCommand('copy');
        } catch (error) {
            console.error('Fallback copy failed:', error);
        }
        
        document.body.removeChild(textArea);
    }

    showToast(message) {
        const toast = document.getElementById('toast');
        const toastMessage = document.getElementById('toastMessage');
        
        toastMessage.textContent = message;
        toast.classList.add('show');
        
        setTimeout(() => {
            toast.classList.remove('show');
        }, 3000);
    }

    showLoading(show) {
        const loading = document.getElementById('loadingSpinner');
        if (show) {
            loading.classList.add('active');
        } else {
            loading.classList.remove('active');
        }
    }

    showError(message) {
        const scriptsGrid = document.getElementById('scriptsGrid');
        scriptsGrid.innerHTML = `
            <div class="error-message" style="grid-column: 1 / -1; text-align: center; padding: 3rem;">
                <i class="fas fa-exclamation-triangle" style="font-size: 3rem; color: #f5576c; margin-bottom: 1rem;"></i>
                <h3>Error Loading Scripts</h3>
                <p style="color: var(--text-secondary); margin-top: 0.5rem;">${message}</p>
                <button onclick="location.reload()" style="margin-top: 1rem; padding: 10px 20px; background: var(--accent-color); border: none; border-radius: 20px; color: white; cursor: pointer;">
                    Try Again
                </button>
            </div>
        `;
    }



    setupScrollAnimations() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('revealed');
                }
            });
        }, observerOptions);

        // Observe all scroll-reveal elements
        document.querySelectorAll('.scroll-reveal').forEach(element => {
            observer.observe(element);
        });
    }

    escapeHtml(text) {
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.replace(/[&<>"']/g, (m) => map[m]);
    }
}

// Initialize the script manager when the page loads
document.addEventListener('DOMContentLoaded', () => {
    new ScriptManager();
});

// Smooth scroll reveal animations
window.addEventListener('scroll', () => {
    const scrolled = window.pageYOffset;
    const parallax = document.querySelector('.nav-saturn');
    if (parallax) {
        parallax.style.transform = `rotate(${scrolled * 0.5}deg)`;
    }
});
